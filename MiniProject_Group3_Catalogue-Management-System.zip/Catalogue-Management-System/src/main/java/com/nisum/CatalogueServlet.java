package com.nisum;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class CatalogueServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String action = req.getParameter("action");
        resp.setContentType("application/json");
        try {
            if ("getActiveCategories".equals(action)) {
                JSONArray categories = getActiveCategories();
                resp.getWriter().write(categories.toString());
            } else if ("getProductsByCategory".equals(action)) {
                int categoryId = Integer.parseInt(req.getParameter("categoryId"));
                JSONArray products = getProductsByCategory(categoryId);
                resp.getWriter().write(products.toString());
            } else if ("getProductInfo".equals(action)) {
                int productId = Integer.parseInt(req.getParameter("productId"));
                JSONObject product = getProductInfo(productId);
                resp.getWriter().write(product.toString());
            } else {
                resp.getWriter().write("{\"error\":\"Invalid action\"}");
            }
        } catch (Exception e) {
            resp.getWriter().write("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String action = req.getParameter("action");
        resp.setContentType("application/json");
        try {
            if ("addCategory".equals(action)) {
                String categoryName = req.getParameter("categoryName");
                addCategory(categoryName);
                resp.getWriter().write("{\"success\":true}");
            } else if ("addProductToCategory".equals(action)) {
                String productName = req.getParameter("productName");
                int categoryId = Integer.parseInt(req.getParameter("categoryId"));
                addProductToCategory(productName, categoryId);
                resp.getWriter().write("{\"success\":true}");
            } else if ("removeProductFromCategory".equals(action)) {
                int productId = Integer.parseInt(req.getParameter("productId"));
                int categoryId = Integer.parseInt(req.getParameter("categoryId"));
                removeProductFromCategory(productId, categoryId);
                resp.getWriter().write("{\"success\":true}");
            } else if ("createPromotion".equals(action)) {
                String promoType = req.getParameter("promoType");
                String promoCode = req.getParameter("promoCode");
                String description = req.getParameter("description");
                double promoAmount = Double.parseDouble(req.getParameter("promoAmount"));
                int promoTypeId = getOrCreatePromoType(promoType);
                createPromotion(promoCode, promoTypeId, description, promoAmount);
                resp.getWriter().write("{\"success\":true,\"message\":\"Promotion created\"}");
            } else {
                resp.getWriter().write("{\"error\":\"Invalid action\"}");
            }
        } catch (Exception e) {
            resp.getWriter().write("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }

    // --- Helper methods ---
    private void addCategory(String categoryName) throws SQLException {
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO Category (CategoryName) VALUES (?)")) {
            ps.setString(1, categoryName);
            ps.executeUpdate();
        }
    }

    private JSONArray getActiveCategories() throws SQLException {
        JSONArray arr = new JSONArray();
        try (Connection conn = DBUtil.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM Category")) {
            while (rs.next()) {
                JSONObject obj = new JSONObject();
                obj.put("CategoryID", rs.getInt("CategoryID"));
                obj.put("CategoryName", rs.getString("CategoryName"));
                arr.put(obj);
            }
        }
        return arr;
    }

    private void addProductToCategory(String productName, int categoryId) throws SQLException {
        try (Connection conn = DBUtil.getConnection()) {
            // Insert product
            PreparedStatement ps = conn.prepareStatement("INSERT INTO Product (ProductName, CategoryID, Status, CreatedDate, LastModifiedDate) VALUES (?, ?, 'Active', NOW(), NOW())", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, productName);
            ps.setInt(2, categoryId);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            int productId = 0;
            if (rs.next()) productId = rs.getInt(1);
            // Link product to category
            PreparedStatement ps2 = conn.prepareStatement("INSERT INTO ProductCategory (CategoryID, ProductID) VALUES (?, ?)");
            ps2.setInt(1, categoryId);
            ps2.setInt(2, productId);
            ps2.executeUpdate();
        }
    }

    private void removeProductFromCategory(int productId, int categoryId) throws SQLException {
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM ProductCategory WHERE ProductID=? AND CategoryID=?");
            ps.setInt(1, productId);
            ps.setInt(2, categoryId);
            ps.executeUpdate();
        }
    }

    private JSONArray getProductsByCategory(int categoryId) throws SQLException {
        JSONArray arr = new JSONArray();
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT p.* FROM Product p JOIN ProductCategory pc ON p.ProductID = pc.ProductID WHERE pc.CategoryID = ?")) {
            ps.setInt(1, categoryId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                JSONObject obj = new JSONObject();
                obj.put("ProductID", rs.getInt("ProductID"));
                obj.put("ProductName", rs.getString("ProductName"));
                obj.put("Status", rs.getString("Status"));
                obj.put("CreatedDate", rs.getTimestamp("CreatedDate"));
                obj.put("LastModifiedDate", rs.getTimestamp("LastModifiedDate"));
                arr.put(obj);
            }
        }
        return arr;
    }

    private JSONObject getProductInfo(int productId) throws SQLException {
        JSONObject obj = new JSONObject();
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM Product WHERE ProductID = ?")) {
            ps.setInt(1, productId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                obj.put("ProductID", rs.getInt("ProductID"));
                obj.put("ProductName", rs.getString("ProductName"));
                obj.put("Status", rs.getString("Status"));
                obj.put("CreatedDate", rs.getTimestamp("CreatedDate"));
                obj.put("LastModifiedDate", rs.getTimestamp("LastModifiedDate"));
            }
        }
        return obj;
    }

    private int getOrCreatePromoType(String promoType) throws SQLException {
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("SELECT PromoTypeId FROM PromotionType WHERE PromoType = ?");
            ps.setString(1, promoType);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("PromoTypeId");
            } else {
                PreparedStatement ps2 = conn.prepareStatement("INSERT INTO PromotionType (PromoType) VALUES (?)", Statement.RETURN_GENERATED_KEYS);
                ps2.setString(1, promoType);
                ps2.executeUpdate();
                ResultSet rs2 = ps2.getGeneratedKeys();
                if (rs2.next()) return rs2.getInt(1);
            }
        }
        throw new SQLException("Failed to get or create promo type");
    }

    private void createPromotion(String promoCode, int promoTypeId, String description, double promoAmount) throws SQLException {
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO Promotions (PromoCode, PromoTypeId, Description, PromoAmount) VALUES (?, ?, ?, ?)");) {
            ps.setString(1, promoCode);
            ps.setInt(2, promoTypeId);
            ps.setString(3, description);
            ps.setDouble(4, promoAmount);
            ps.executeUpdate();
        }
    }
}

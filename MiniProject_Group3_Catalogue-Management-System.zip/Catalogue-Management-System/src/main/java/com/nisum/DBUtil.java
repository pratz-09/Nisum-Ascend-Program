package com.nisum;

import javax.servlet.annotation.WebServlet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@WebServlet("/DBUtil")
public class DBUtil {
    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/catalogue_db";
        String user = "root";
        String password = "prateek1234";
        return DriverManager.getConnection(url, user, password);
    }
}
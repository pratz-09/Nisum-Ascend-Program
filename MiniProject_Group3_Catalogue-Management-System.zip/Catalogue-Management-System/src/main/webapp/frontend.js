fetch('/CatalogueManagementSystem/api/catalogue')
    .then(response => response.json())
    .then(data => {
        console.log(data);
        // Use the data in your frontend
    });

// Helper to handle API requests
function apiRequest(action, params = {}, method = 'POST') {
    const url = '/CatalogueManagementSystem/api/catalogue';
    const formData = new URLSearchParams({ action, ...params });
    return fetch(url, {
        method,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData
    }).then(res => res.json());
}

// Add Category
function addCategory() {
    const name = document.getElementById('categoryName').value;
    apiRequest('addCategory', { categoryName: name })
        .then(data => alert(data.success ? 'Category added!' : data.error));
}

// Get Active Categories
function getActiveCategories() {
    fetch('/CatalogueManagementSystem/api/catalogue?action=getActiveCategories')
        .then(res => res.json())
        .then(data => {
            const list = document.getElementById('categoryList');
            list.innerHTML = '';
            data.forEach(cat => {
                const li = document.createElement('li');
                li.textContent = cat.CategoryName + ' (ID: ' + cat.CategoryID + ')';
                list.appendChild(li);
            });
        });
}

// Add Product to Category
function addProductToCategory() {
    const name = document.getElementById('productName').value;
    const catId = document.getElementById('productCategoryId').value;
    apiRequest('addProductToCategory', { productName: name, categoryId: catId })
        .then(data => alert(data.success ? 'Product added!' : data.error));
}

// Remove Product from Category
function removeProductFromCategory() {
    const prodId = document.getElementById('removeProductId').value;
    const catId = document.getElementById('removeCategoryId').value;
    apiRequest('removeProductFromCategory', { productId: prodId, categoryId: catId })
        .then(data => alert(data.success ? 'Product removed!' : data.error));
}

// Get Products by Category
function getProductsByCategory() {
    const catId = document.getElementById('getProductsCategoryId').value;
    fetch('/CatalogueManagementSystem/api/catalogue?action=getProductsByCategory&categoryId=' + catId)
        .then(res => res.json())
        .then(data => {
            const list = document.getElementById('productList');
            list.innerHTML = '';
            data.forEach(prod => {
                const li = document.createElement('li');
                li.textContent = prod.ProductName + ' (ID: ' + prod.ProductID + ')';
                list.appendChild(li);
            });
        });
}

// Fetch Product Info
function getProductInfo() {
    const prodId = document.getElementById('infoProductId').value;
    fetch('/CatalogueManagementSystem/api/catalogue?action=getProductInfo&productId=' + prodId)
        .then(res => res.json())
        .then(data => {
            document.getElementById('productInfo').textContent = JSON.stringify(data, null, 2);
        });
}

// Create Promotion
function createPromotion() {
    const promoType = document.getElementById('promoType').value;
    const promoCode = document.getElementById('promoCode').value;
    const description = document.getElementById('promoDescription').value;
    const promoAmount = document.getElementById('promoAmount').value;
    apiRequest('createPromotion', { promoType, promoCode, description, promoAmount })
        .then(data => alert(data.success ? 'Promotion created!' : data.error));
}

// Attach event listeners after DOM loads
window.onload = function() {
    document.getElementById('addCategoryBtn').onclick = addCategory;
    document.getElementById('getCategoriesBtn').onclick = getActiveCategories;
    document.getElementById('addProductBtn').onclick = addProductToCategory;
    document.getElementById('removeProductBtn').onclick = removeProductFromCategory;
    document.getElementById('getProductsBtn').onclick = getProductsByCategory;
    document.getElementById('getProductInfoBtn').onclick = getProductInfo;
    document.getElementById('createPromotionBtn').onclick = createPromotion;
};

